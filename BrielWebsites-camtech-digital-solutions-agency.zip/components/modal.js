class CustomModal extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.render();
        this.addEventListeners();
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: none;
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    z-index: 1000;
                    align-items: center;
                    justify-content: center;
                }

                .modal-container {
                    background: white;
                    border-radius: 1rem;
                    padding: 1.5rem;
                    max-width: 90vw;
                    max-height: 90vh;
                    overflow-y: auto;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
                    animation: modalEnter 0.3s ease-out;
                }

                @keyframes modalEnter {
                    from {
                        opacity: 0;
                        transform: scale(0.9) translateY(-20px);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1) translateY(0);
                    }
                }

                .modal-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 1rem;
                }

                .modal-title {
                    font-size: 1.5rem;
                    font-weight: bold;
                    color: #1f2937;
                }

                .close-button {
                    background: none;
                    border: none;
                    color: #6b7280;
                    cursor: pointer;
                    padding: 0.5rem;
                    border-radius: 0.375rem;
                    transition: color 0.2s;
                }

                .close-button:hover {
                    color: #374151;
                }
            </style>
            <div class="modal-container">
                <div class="modal-header">
                    <h3 class="modal-title"><slot name="title"></slot></h3>
                    <button class="close-button">
                        <i data-feather="x"></i>
                    </button>
                </div>
                <div class="modal-content">
                    <slot name="content"></slot>
                </div>
            </div>
        `;
    }

    addEventListeners() {
        const closeButton = this.shadowRoot.querySelector('.close-button');
        closeButton.addEventListener('click', () => {
            this.close();
        });

        // Close when clicking outside
        this.shadowRoot.host.addEventListener('click', (e) => {
            if (e.target === this.shadowRoot.host) {
                this.close();
            }
        });
    }

    open() {
        this.style.display = 'flex';
        feather.replace();
    }

    close() {
        this.style.display = 'none';
    }
}

customElements.define('custom-modal', CustomModal);